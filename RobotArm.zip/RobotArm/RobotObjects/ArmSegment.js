"use strict";
var ArmSegment = (function()
{

}) ();
