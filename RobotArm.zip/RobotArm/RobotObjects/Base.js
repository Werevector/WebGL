"use strict"
var Base = (function()
{
  
}) ();
